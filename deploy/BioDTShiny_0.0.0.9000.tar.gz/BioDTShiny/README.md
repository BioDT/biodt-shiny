# biodt-shiny
This repository contains a shiny application which is intended as the simplest way of interacting with BioDT by end-users.
